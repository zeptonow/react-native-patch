function a([]) {}
