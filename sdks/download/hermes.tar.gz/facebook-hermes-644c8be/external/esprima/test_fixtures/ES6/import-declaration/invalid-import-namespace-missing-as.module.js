import * from "foo"
