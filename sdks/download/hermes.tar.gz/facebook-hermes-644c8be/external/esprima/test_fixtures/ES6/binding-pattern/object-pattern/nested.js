let {a:{}} = 0
