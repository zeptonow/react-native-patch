export {foo as default};
