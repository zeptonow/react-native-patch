var [] = 0;
