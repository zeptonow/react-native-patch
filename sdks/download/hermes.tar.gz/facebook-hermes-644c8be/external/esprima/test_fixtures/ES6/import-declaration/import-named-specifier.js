import {bar} from "foo";
