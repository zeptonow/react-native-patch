({ *foo() { yield; } })
