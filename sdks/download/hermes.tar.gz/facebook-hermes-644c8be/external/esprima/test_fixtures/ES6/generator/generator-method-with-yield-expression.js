({ *foo() { yield 3; } })
