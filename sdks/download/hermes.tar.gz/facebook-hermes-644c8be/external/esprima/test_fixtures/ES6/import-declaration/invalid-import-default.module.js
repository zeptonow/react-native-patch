import default from "foo"
