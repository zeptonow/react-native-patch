({ *foo() { 
  yield
  3
} })
