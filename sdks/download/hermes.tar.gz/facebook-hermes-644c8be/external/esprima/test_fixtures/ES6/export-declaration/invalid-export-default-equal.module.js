export default = 42
