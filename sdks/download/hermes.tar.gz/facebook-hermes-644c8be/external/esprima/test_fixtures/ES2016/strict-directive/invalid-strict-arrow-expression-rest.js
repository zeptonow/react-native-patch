(...x) => { "use strict" }
