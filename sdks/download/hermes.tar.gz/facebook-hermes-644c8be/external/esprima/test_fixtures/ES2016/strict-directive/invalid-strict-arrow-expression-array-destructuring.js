([]) => { "use strict" }
